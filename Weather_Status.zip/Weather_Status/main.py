# Weather status check
# MAde by Alex Pokorskiy
# About: API based program that requires an API key to check weather status of a desired location

import datetime as dtm
import requests


# Primary link used: https://api.openweathermap.org/data/2.5/forecast?q=calgary&appid=*****************************
# Kelvin to Celsius conversion formula: C = K – 273.15
def city_func():  # Function that will have the user input the city name
    print("Welcome to the API weather software: ")
    return input("Please enter the name of the city: ").lower()


key = open("api.txt", "r").read()
start_url = "https://api.openweathermap.org/data/2.5/forecast?"
city = city_func()
print(city)
full_url = start_url + "&q=" + city + "&appid=" + key
reply = requests.get(full_url).json()


def kelvin_conversion(kelvin):
    cel = kelvin - 273.15
    fer = cel * (9 / 5) + 32
    return (cel, fer)  # tuple of Celsius and Fahrenheit results


humidity = reply['list'][0]['main']['humidity']  # pulling the humidity value from the API
weather = reply['list'][0]['weather'][0]['main']  # pulling the weather title value from the API
weather_description = reply['list'][0]['weather'][0][
    'description']  # pulling the weather description value from the API
api_kelvin = reply['list'][0]['main']['temp']  # pulling the current temperature in Kelvin (default) value from the API

sunrise = reply['city']['sunrise']  # pulling the sunrise time value from the API
sunset = reply['city']['sunset']  # pulling the sunset time value from the API
timezone = reply['city']['timezone']  # pulling the timezone value from the API

t_cel, t_fer = kelvin_conversion(api_kelvin)  # formula to calculate the temperature in Celsius and Fahrenheit
sunset_conversion = dtm.datetime.utcfromtimestamp(sunset + timezone)  # formulate using the datetime conversion
# function to calculate the proper sunset time based on the timezone value
sunrise_conversion = dtm.datetime.utcfromtimestamp(sunrise + timezone)  # formulate using the datetime conversion
# function to calculate the proper sunrise time based on the timezone value

print("===============================================================================")
print(full_url)
print(weather + " - " + weather_description)
print("Humidity:" + str(humidity))
print("Temperature: ")
print(str("{:.2f}".format(t_cel)) + "C  " + str("{:.2f}".format(t_fer)) + "F  " + str("{:.2f}".format(api_kelvin))+"K")
print("Sunrise: " + str(sunrise_conversion))
print("Sunset: " + str(sunset_conversion))
print("===============================================================================")