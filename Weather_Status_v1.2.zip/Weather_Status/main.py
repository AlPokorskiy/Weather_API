# Weather status check
# MAde by Alex Pokorskiy
# About: API based program that requires an API key to check weather status of a desired location

import tkinter
import datetime as dtm
from tkinter import messagebox
import requests

window = tkinter.Tk()
window.title("Weather API")
window.geometry('550x650')
window.configure()

frame = tkinter.Frame(bd=20)
frame.configure()

api_key_title = tkinter.Label(window, text="WEATHER API KEY", font=("Arial", 22))
api_key_label = tkinter.Label(window, text="API KEY: ", font=("Arial", 16))
api_key_entry = tkinter.Entry(window, font=("Arial", 14), show="#")

city_label = tkinter.Label(window, text="City: ", font=("Arial", 16))
city_entry = tkinter.Entry(window, font=("Arial", 14))

api_key_title.grid(row=0, column=2, columnspan=3, sticky="news", pady=20, padx=140)

api_key_label.grid(row=1, column=2)
api_key_entry.grid(row=1, column=3)

city_label.grid(row=2, column=2)
city_entry.grid(row=2, column=3, pady=10)


def submit_api():
    start_url = "https://api.openweathermap.org/data/2.5/forecast?"
    full_url = start_url + "&q=" + (city_entry.get()).lower() + "&appid=" + api_key_entry.get()
    reply = requests.get(full_url).json()

    if reply['cod'] == 401:
        messagebox.showerror(title="Error: 401", message=reply['message'])
    elif reply['cod'] == '404':
        messagebox.showerror(title="Error: 404", message=reply['message'])
    elif reply['cod'] == '200':
        humidity = reply['list'][0]['main']['humidity']  # pulling the humidity value from the API
        weather = reply['list'][0]['weather'][0]['main']  # pulling the weather title value from the API
        weather_description = reply['list'][0]['weather'][0][
            'description']  # pulling the weather description value from the API
        api_kelvin = reply['list'][0]['main'][
            'temp']  # pulling the current temperature in Kelvin (default) value from the API
        country_name = reply['city']['country']
        city_name = reply['city']['name']
        sunrise = reply['city']['sunrise']  # pulling the sunrise time value from the API
        sunset = reply['city']['sunset']  # pulling the sunset time value from the API
        timezone = reply['city']['timezone']  # pulling the timezone value from the API

        t_cel, t_fer = kelvin_conversion(api_kelvin)  # formula to calculate the temperature in Celsius and Fahrenheit
        sunset_conversion = dtm.datetime.utcfromtimestamp(sunset + timezone)  # formulate using the datetime conversion
        # function to calculate the proper sunset time based on the timezone value
        sunrise_conversion = dtm.datetime.utcfromtimestamp(
            sunrise + timezone)  # formulate using the datetime conversion
        # function to calculate the proper sunrise time based on the timezone value

        info = str(str(city_name).capitalize() + ", " + str(country_name).upper() + "\n"
                   + weather + " - " + weather_description + "\n"
                   + "\nHumidity: " + str(humidity) + "\n"
                   + "\nTemperature: " + "\n"
                   + str("{:.1f}".format(t_cel)) + "C  " + "\n"
                   + str("{:.1f}".format(t_fer)) + "F  " + "\n"
                   + str("{:.1f}".format(api_kelvin)) + "K" + "\n"
                   + "\nSunrise: " + str(sunrise_conversion) + "\n"
                   + "Sunset: " + str(sunset_conversion))

        host_widgets(info)


def host_widgets(info):
    info_label = tkinter.Label(frame, text=info, font=("Arial", 14))
    info_label.grid(row=1, column=0, columnspan=4, pady=5)

    save_button = tkinter.Button(window, text="export", font=("Arial", 12), command=export_data)
    save_button.grid(row=6, column=2, pady=25)


def export_data():
    start_url = "https://api.openweathermap.org/data/2.5/forecast?"
    full_url = start_url + "&q=" + city_entry.get() + "&appid=" + api_key_entry.get()
    data_raw = requests.get(full_url).json()

    with open("data_JSOn.txt", "w") as dump_txt:
        dump_txt.write(str(data_raw))


def kelvin_conversion(kelvin):
    cel = kelvin - 273.15
    fer = cel * (9 / 5) + 32
    return cel, fer  # tuple of Celsius and Fahrenheit results


submission_button = tkinter.Button(window, text="Submit", font=("Arial", 12), command=submit_api)
submission_button.grid(row=4, column=2, pady=25)

frame.grid(row=5, columnspan=3, column=2)

window.mainloop()

# Primary link used: https://api.openweathermap.org/data/2.5/forecast?q=calgary&appid=*****************************
# Kelvin to Celsius conversion formula: C = K – 273.15

